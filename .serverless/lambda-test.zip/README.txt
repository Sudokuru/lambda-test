Steps taken:
1. mkdir and cd
2. npm init -y
3. npm install express
4. touch app.ts and added that code
5. npm i serverless-http
6. sudo npm install -g serverless
7. serverless --version to check installl
8. export AWS_ACCESS_KEY_ID= then can test using printenv
9. export AWS_SECRET_ACCESS_KEY=
10. touch serverless.yml and add that code
11. serverless deploy (do this last)
12. npm install mongodb express cors dotenv
13. mkdir routes and touch record.ts and added that code
14. tsc app.ts and record.ts