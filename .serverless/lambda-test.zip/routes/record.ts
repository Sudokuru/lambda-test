const express = require("express");

// recordRoutes controls requests starting with /record
const recordRoutes = express.Router();

module.exports = recordRoutes;