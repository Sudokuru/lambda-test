var express = require("express");
// recordRoutes controls requests starting with /record
var recordRoutes = express.Router();
module.exports = recordRoutes;
